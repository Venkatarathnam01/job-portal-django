from django.db import models
from candidate_app.models import Candidate

#7.......
class Recruiter(models.Model):
    username = models.CharField(max_length=200)
    name = models.CharField(max_length=200)
    email = models.EmailField()
    phone = models.PositiveBigIntegerField()
    password = models.CharField(max_length=200)

    def __str__(self):
        return self.name
#8.....
class RecruiterDetail(models.Model):
    user = models.OneToOneField(Recruiter,on_delete=models.CASCADE)
    bio = models.TextField()
    address = models.TextField()
    city = models.CharField(max_length=200)
    state = models.CharField(max_length=200)
    pincode = models.CharField(max_length=200)
    country = models.CharField(max_length=200)
    profile_pic = models.ImageField(upload_to='recruiterdp/',null=True)



    def __str__(self):
        return self.user.name

class JobDetail(models.Model):
    recruiter = models.ForeignKey(Recruiter,on_delete=models.CASCADE)
    company_name = models.CharField(max_length=200)
    company_address = models.TextField()
    company_image = models.ImageField(upload_to="companyimage/",null=True)
    job_role = models.CharField(max_length=200)
    skills = models.TextField()
    job_description = models.TextField()
    salary_range = models.CharField(max_length=200)
    experience_required = models.CharField(max_length=200)
    qualification = models.CharField(max_length=200)
    vacancy = models.CharField(max_length=100)
    location = models.CharField(max_length=200)
    employement_type = models.CharField(max_length=200)
    industry =models.CharField(max_length=200)
    job_posted = models.DateField(auto_now_add=True)
    last_date = models.DateField()
    hiring_process = models.TextField()


    def __str__(self):
        return self.job_role

#10....
class JobApplied(models.Model):
    job_detail = models.ForeignKey(JobDetail,on_delete=models.CASCADE)
    recruiter = models.ForeignKey(Recruiter,on_delete=models.CASCADE)
    candidate = models.ForeignKey(Candidate,on_delete=models.CASCADE)
    scheduled = models.BooleanField(default=False)


    def __str__(self):
        return f"{self.Candidate.name} applied for {self.job_detail.job_role}"

